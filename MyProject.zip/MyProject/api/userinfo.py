from MyProject.model.usermodel import userModel
User=userModel()
# 登录检验（用户名、密码验证）
def valid_loginImpl(username, password):
    resjson = {}
    user=User.query(username)
    print("输入的用户名是"+str(username))
    if user:
        pwd=user.password
        if pwd==password:
            resjson['status']=1
            resjson['msg']='登录成功'
            resjson['result']={}
            resjson['result']['userid']=user.id
            resjson['result']['username']=user.username
            resjson['result']['password'] = user.password
            return resjson
        else:
            resjson['status']=-2
            resjson['msg']='密码错误'
            return resjson
    else:
        resjson['status']=-1
        resjson['msg']='账号不存在'
        return resjson


# 查看所有的用户信息
def all_userImpl():
    resjson = {}
    users = User.query_all()
    for user in users:
        user=user.__dict__
        id=user['id']
        name='id_'+str(id)
        resjson[name]={}
        resjson[name]['userid']=user['id']
        resjson[name]['username'] = user['username']
    return resjson



if __name__ == '__main__':
    result=all_userImpl()

    # print("最终结果："+str(result))