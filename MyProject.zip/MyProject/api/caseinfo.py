
from MyProject.model.casemodel import *
Case=CaseModel()
# 新增用例--传入值来
def add_case(taskid,casemodel,casname,caseurl,casemothod,caseparam,casepr,casestatus,casepresult,casefresult,casetime,caseremark,casesid='',casepre=''):
    resjson={}
    case=Case.insert(taskid,casemodel,casname,caseurl,casemothod,caseparam,casepr,casestatus,casepresult,casefresult,casetime,caseremark,casesid,casepre)
    if case:
        resjson['status'] = 1
        resjson['msg'] = "创建用例成功"
        return resjson
    else:
        resjson['status'] = 0
        resjson['msg'] = "创建用例失败"
        return resjson

# 修改用例--根据传入的值来进行修改
def modify_case(id,taskid,casemodel,casname,caseurl,casemothod,caseparam,casepr,casestatus,casepresult,casesid='',casepre=''):
    resjson={}
    cc=Case.query("id",id)
    if cc:
        case=Case.update(id,taskid,casemodel,casname,caseurl,casemothod,caseparam,casepr,casestatus,casepresult,casesid,casepre)
        if case:
            resjson['status'] = 1
            resjson['msg'] = "修改用例成功"
            return resjson
        else:
            resjson['status'] = 0
            resjson['msg'] = "修改用例失败"
            return resjson
    else:
        resjson['status'] = -1
        resjson['msg'] = "无相关信息"
        return resjson

# 删除用例--根据id 或 taskid删除，根据taskid+caseid删除
def delete_case(id,taskid):
    resjson={}
    case=Case.delete(id,taskid)
    if case==0:
        resjson['status'] = -2
        resjson['msg'] = "无相关用例信息"
        return resjson
    if case>=0:
        resjson['status'] = 1
        resjson['msg'] = "删除用例成功"
        return resjson
    else:
        resjson['status'] = 0
        resjson['msg'] = "删除用例失败"
        return resjson

def delete_case_group(taskid,casesid):
    resjson={}
    case=Case.delete_case_group(taskid,casesid)
    if case:
        resjson['status'] = 1
        resjson['msg'] = "删除用例成功"
        return resjson
    else:
        resjson['status'] = 0
        resjson['msg'] = "删除用例失败"
        return resjson

# 查询用例---根据taskid 或 taskid+casesid查询
def find_case_all(taskid,casesid):
    resjson = {}
    if casesid:
        cases = Case.querys_all(taskid,casesid)
        print("用例查询的结果是"+cases)
        if cases:
            resjson['status'] = 1
            resjson['msg'] = "查询用例成功"
            for case in cases:
                name="id_"+str(case.id)
                dictname = resjson[name] = {}
                obtain_case_value(dictname, case)
            return resjson
        else:
            resjson['status'] = 0
            resjson['msg'] = "查询用例失败"
            return resjson
    else:
        cases=Case.querys_all(taskid)
        if cases:
            resjson['status'] = 1
            resjson['msg'] = "查询用例成功"
            for case in cases:
                name="id_"+str(case.id)
                dictname = resjson[name] = {}
                obtain_case_value(dictname, case)
            return resjson
        else:
            resjson['status'] = 0
            resjson['msg'] = "查询用例失败"
            return resjson


#将字段打印出来
def obtain_case_value(dictname,case):
    dictname['id'] = case.id
    dictname['taskid'] = case.taskid
    dictname['casesid'] = case.casesid
    dictname['casemodel'] = case.casemodel
    dictname['casname'] = case.casname
    dictname['caseurl'] = case.caseurl
    dictname['casepre'] = case.casepre
    dictname['casemothod'] = case.casemothod
    dictname['caseparam'] = case.caseparam
    dictname['casepr'] = case.casepr
    dictname['casestatus'] = case.casestatus
    dictname['casepresult'] = case.casepresult
    dictname['casefresult'] = case.casefresult
    dictname['casetime'] = case.casetime
    dictname['caseremark'] = case.caseremark



