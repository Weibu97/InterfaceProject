# 系统参数，用于设置全局变量
# # id
# # taskid 与任务的id相联系，一个任务可以设置多个系统参数，不同的任务可以设置相同的参数名
# # gcsname 全局变量的参数名，可以重复，但是taskid-gcsname不能重复
# # gcsvalue  全局变量的参数值
# # gcstime  全局变量的设置时间
from MyProject.model.xtcsmodel import XTCSModel
from MyProject.model.taskmodel import TaskModel
from MyProject.api.taskinfo import *
Task=TaskModel()
XTCS=XTCSModel()
#添加参数值，设置全局，全部任务下都适用的
def add_global_xtcs(gcsname,gcsvalue,taskid=0):
    resjson={}
    xtcs=XTCS.querys(taskid,gcsname)
    if xtcs:
        resjson['status']=-1
        resjson['msg']='该变量名已存在'
        return resjson
    else:
        xtcs=XTCS.insert(gcsname,gcsvalue,taskid)
        if xtcs:
            resjson['status'] = 1
            resjson['msg'] = '新增变量成功'
            return resjson
        else:
            resjson['status'] = 0
            resjson['msg'] = '新增变量失败'
            return resjson


#修改变量名
def modify_global_xtcsname(gcsname,gcsvalue,taskid=0):
    resjson={}
    xtcs=XTCS.query("taskid",taskid)
    if xtcs:
        xtcs=XTCS.query(taskid,gcsname)
        if xtcs:
            resjson['status']=-2
            resjson['msg']='该变量名已存在'
            return resjson
        else:
            xtcs=XTCS.update(gcsname,gcsvalue,taskid)
            if xtcs:
                resjson['status'] = 1
                resjson['msg'] = '修改变量成功'
                result = resjson['result'] = {}
                obtain_xtcs_value(result, xtcs)
                return resjson
            else:
                resjson['status'] = 0
                resjson['msg'] = '修改变量失败'
                return resjson
    else:
        resjson['status'] = -1
        resjson['msg'] = '无相关参数设置'


#删除变量名
#根据id删除任务
def delete_xtcs(taskid,gcsname):
    resjson={}
    xtcs=XTCS.querys(taskid,gcsname)
    if xtcs:
        xtcs=XTCS.delete(gcsname,taskid)
        if xtcs:
            resjson['status'] = 1
            resjson['msg'] = "删除任务成功"
            return resjson
        else:
            resjson['status'] = 0
            resjson['msg'] = "删除任务失败"
            return resjson
    else:
        resjson['status'] = -1
        resjson['msg'] = "无相关任务信息"
        return resjson


#查询变量名，根据taskid来查询
def find_xtcs_all(taskid):
    resjson={}
    try:
        xtcss=XTCS.querys_all(taskid)
        print("hshhshshsh"+str(len(xtcss)))
        if xtcss:
            resjson['status'] = 1
            resjson['msg'] = "查询成功"
            if len(xtcss)==1:
                dictname = resjson['result'] = {}
                obtain_xtcs_value(dictname, xtcss)
                return resjson
            else:
                s = 0
                for i in xtcss:
                    s+=1
                    name = "id_" + str(s)
                    dictname = resjson[name] = {}
                    obtain_xtcs_value(dictname, i)
                return resjson
        else:
            resjson['status'] = 0
            resjson['msg'] = "查询任务失败"
            return resjson
    except:
        resjson['status'] = -1
        resjson['msg'] = "无相关任务信息"
        return resjson



#将字段打印出来
def obtain_xtcs_value(dictname,xtcs):
    dictname['taskid'] = xtcs.taskid
    dictname['gcsname'] = xtcs.gcsname
    dictname['gcsvalue'] = xtcs.gcsvalue
    dictname['gcstime'] = xtcs.gcstime
    return dictname


