from MyProject.model.taskmodel import TaskModel
from MyProject.Common.log import *
log=Demolog().log()

Task=TaskModel()
#新增任务，入参userid,taskname,taskplain
def add_task(userid,taskname,taskeplain):
    resjson = {}
    log.info("正在检查taskname，查看是否已存在")
    task = Task.query('taskname',taskname)
    if task is None:
        log.info("taskname不存在，正在执行插入操作")
        task = Task.insert(userid, taskname, taskeplain)
        if task:
            resjson['status'] = 1
            resjson['msg'] = "创建任务成功"
            return resjson
        else:
            log.error("执行插入操作失败")
            resjson['status'] = 0
            resjson['msg'] = "创建任务失败"
            return resjson
    if task is not None:
        log.error("检查taskname，taskname已存在")
        resjson['status'] = -1
        resjson['msg'] = "此任务名已存在"
        return resjson




#修改任务，入参id,taskname
def modify_taskname(id,taskname,taskexplain):
    resjson = {}
    log.info("修改任务，正在检查任务id是否存在，id为"+str(id))
    task=Task.query('id',id)
    if task:
        log.info("任务id检查完成，该任务id是真实存在的,正在查询taskname，查询的taskname值为"+str(taskname))
        task=Task.query('taskname',taskname)
        if task:
            log.error("查询taskname完成，该taskname已存在，不能进行修改")
            resjson['status']=-1
            resjson['msg']="此任务名已存在"
            return resjson
        else:
            log.info("查询taskname完成，该taskname不存在，正在执行修改操作")
            up_task=Task.update(id,taskname,taskexplain)
            if up_task:
                log.info("修改任务执行成功")
                resjson['status'] = 1
                resjson['msg'] = "修改任务成功"
                return resjson
            else:
                log.error("在修改的过程中，遇到错误")
                resjson['status']=0
                resjson['msg']="修改任务失败"
                return resjson
    else:
        log.warning("传入修改的任务id是不存在的，无法进行修改")
        resjson['status'] = -2
        resjson['msg'] = "无相关任务信息"
        return resjson


#根据id删除任务
def delete_task(id):
    resjson={}
    log.info("删除任务，正在检查任务id是否存在，id为" + str(id))
    #先查询是否存在这个任务编号，存在就删除，不存在返回-1
    task=Task.query('id',id)
    if task:
        log.info("任务id检查完成，该任务id是真实存在的,正在执行删除")
        #执行删除操作，如果返回True 表示删除成功，Flase表示失败
        task=Task.delete(id)
        if task:
            log.info("删除任务成功")
            resjson['status'] = 1
            resjson['msg'] = "删除任务成功"
            return resjson
        else:
            log.error("删除任务过程中遇到错误")
            resjson['status'] = 0
            resjson['msg'] = "删除任务失败"
            return resjson
    else:
        log.warning("传入修改的任务id是不存在的，无法进行删除")
        resjson['status'] = -1
        resjson['msg'] = "无相关任务信息"
        return resjson

#根据任务的id来查询任务信息
def find_task_by_id(id):
    resjson = {}
    log.info("查询任务，正在检查任务id是否存在，id为" + str(id))
    tasks=Task.query('id',id)
    if tasks:
        resjson['status'] = 1
        resjson['msg'] = "查询成功"
        dictname=resjson['result']={}
        obtain_task_value(dictname,tasks)
        log.info("任务id检查完成，该任务id是真实存在的,该id查询出的数据为" + resjson)
        return resjson
    else:
        log.error("查询任务过程中遇到错误")
        resjson['status']=0
        resjson['msg']="查询失败"
        return resjson


#根据任务的userid来查询任务信息
def find_task_by_userid(userid):
    resjson = {}
    log.info("查询任务，正在检查任务userid是否存在，userid为" + str(userid))
    tasks=Task.querys_all_userid(userid)
    if tasks:
        resjson['status'] = 1
        resjson['msg'] = "查询成功"
        dictname=resjson['result']={}
        obtain_task_value(dictname,tasks)
        log.info("任务查询成功，该userid是下的任务数据为" + resjson)
        return resjson
    else:
        resjson['status']=0
        resjson['msg']="查询失败"
        return resjson


#查询全部任务信息
def find_task_all():
    resjson={}
    log.info("正在查询全部的任务信息")
    tasks = Task.querys_all()
    if tasks:
        log.info("查询全部任务信息成功")
        for task in tasks:
            name = "id_" + str(task.id)
            dictname = resjson[name] = {}
            obtain_task_value(dictname, task)
        return resjson
    else:
        log.error("在查询的过程中遇到了错误")
        resjson['status'] = 0
        resjson['msg'] = "查询失败"
        return resjson

#将字段打印出来
def obtain_task_value(dictname,task):
    dictname['id'] = task.id
    dictname['userid'] = task.userid
    dictname['taskname'] = task.taskname
    dictname['taskexplain'] = task.taskexplain
    dictname['taskstatus'] = task.taskstatus
    dictname['taskresult'] = task.taskresult
    dictname['tasktime'] = task.tasktime



if __name__ == '__main__':
    # result=add_task(1,'注册中心88','注册中心')
#     # print(result)
    result=find_task_all()
    print(result)
    # find_task('  ')
