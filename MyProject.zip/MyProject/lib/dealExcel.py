import xlrd
import xlwt
import time
from xlutils.copy import copy
class DealFile:

    def __init__(self,Filepath,site):
        #使用xlrd来读取文件，并使用参数formatting_info=True，保存之前数据的格式
        self.filepath = xlrd.open_workbook(Filepath, formatting_info=True)
        #然后用copy去从打开的xlrd的Book变量中，拷贝出一份，成为新的xlwt的Workbook变量
        self.wb = copy(self.filepath)
        self.sheet = self.filepath.sheet_by_index(site)
    #获取表格中所有的内容,不包括首行
    def get_content(self):
        self.TestCase=[]
        for row in range(1,self.sheet.nrows):
            self.TestCase.append(self.sheet.row_values(row))
        return self.TestCase
    #获取到表格中的所有列，包括首行
    def get_rownum(self):
        return self.sheet.nrows
    #处理预期结果中的字符串
    def deal_msg(self,msg):
        self.msgg=msg.split("=")
        return self.msgg

    #获取到某行所需要的值，固定死，入参所有内容和所需要获取的列
    def obtain_rows_content(self,b,row):
        try:
            method = b[row][1]
            url = b[row][2]
            json = eval(b[row][3])
            msg = b[row][4]
            msg2 = self.deal_msg(msg)[0]
            asser = self.deal_msg(msg)[1]
            return method,url,json,msg2,asser
        except Exception as e:
            return str(e)

    def result_input_Excel(self,row,result):
        #通过get_sheet去获得对应的sheet
        ws = self.wb.get_sheet(0)
        #拿到sheet变量后，就可以往sheet中，写入新的数据行、列、值，默认第5列
        if result=="成功":
            styleBlueBkg = xlwt.easyxf('pattern: pattern solid, fore_colour green;')  # 绿色
        else:
            styleBlueBkg = xlwt.easyxf('pattern: pattern solid, fore_colour red;')  # 红色
        ws.write(row, 5, str(result), styleBlueBkg )
        ws.write(row,6,time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    def write_Excel(self):
        self.wb.save(r"C:\Users\WJBu\Desktop\接444.xls")

if __name__ == '__main__':

    c=DealFile(r'C:\Users\WJBu\Desktop\接.xls',0)
    print(c.result_input_Excel(r'C:\Users\WJBu\Desktop\接.xls'))
