from MyProject.lib.dealExcel import *
from MyProject.lib.deakInterface import *
def Interface_By_Excel(url,site):
    Excel=DealFile(url,site)
    #获取到该Excel文件中所有内容，不包括首行
    Excelcontent=Excel.get_content()
    Inter=Interface()
    #获取到Excel中全部的值
    rows=Excel.get_rownum()
    #遍历出每行去执行效验接口，由于rows是获取全部行，所以包含了首行，则要减去1
    for row in range(rows-1):
        try:
            element = Excel.obtain_rows_content(Excelcontent, row)
            result=Inter.interface(element[0],element[1],element[2],element[3],element[4])
            #将结果写入Excel中，row的值是从0开始的，但写入的时候是从第二行开始的 所以索引要加1
        except Exception as e:
            return str(e)
        Excel.result_input_Excel(row+1,"chengg")
        Excel.write_Excel()
    print("执行结束")



