import requests
class Interface:
    #接口，入参方法，url地址，还要json格式的参数值，断言的取的判断名，断言结果是
    def interface(self,method,url,json,msg,asser):
        try:
            if method.lower()=="post":
                rs=requests.post(url,params =json)
            elif method.lower()=="get":
                rs = requests.get(url, params=json)
            # 获取到返回的字典结果中的msg的值
            mss = rs.json()[msg]
        except Exception as e:
            return "接口请求出错！"

        if asser in mss:
            return "成功"
        else:
            return "失败了"+"原因是"+mss


if __name__ == '__main__':
    a=Interface()
    json2 = {'username': 13800138006, 'password': 123456, 'verify_code': 2222}
    print(type(json2))
    a.interface("post",'http://www.testingedu.com.cn:8000/index.php?m=Home&c=User&a=do_login',
                '{\n    "username" : 13800138006,\n    "password" : 123456,\n    "verify_code" : 2222\n}'
                ,"msg","登陆成功")