from MyProject.lib.test import Interface_By_Excel

if __name__ == '__main__':
    Interface_By_Excel(r'C:\Users\WJBu\Desktop\接.xls',0)