# from flask import Flask
# #实例化flask 应用对象
# app=Flask(__name__)
#
# @app.route(rule="/",methods=["get"])
# def index():
#     return "hhhh"
#
# if __name__ == '__main__':
#     app.run(debug=True,host="127.0.0.1",port=9999)
from MyProject.model.model import User
from MyProject.web import db
if __name__=="__main__":
    flag=0
    #定义一个flag来进行开关，是创建表、情况表 还是要插入数据
    if flag==0:
        # db.drop_all() ##清空表
        db.create_all()#创建所有表，所有的db.Model
    if flag==1:
        tag0=User(username='aa',password='aaa',email="24456821@qq.com",phone='8001820',img='')
        tag1 = User(username='bb',password='bbb',email="822596810@qq.com",phone='13896520240',img='')
        db.session.add(tag0)
        db.session.add(tag1)
        db.session.commit()