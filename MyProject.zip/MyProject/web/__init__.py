from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
#实例化flask 应用对象
app = Flask(__name__)
CORS(app, resources=r'/*')
#在flask项目中，Session, Cookies以及一些第三方扩展都会用到SECRET_KEY值，这是一个比较重要的配置值。
app.config['SECRET_KEY'] = '123456'
# SQLALCHEMY_TRACK_MODIFICATIONS = True
#可以在请求结束时自动提交数据库数据,不用手动提交,
SQLALCHEMY_COMMIT_TEARDOWN = True
#用于连接的数据库 URI
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root@localhost:3306/myweb?charset=utf8'
# 每次请求结束后都会自动提交数据库中的变动
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
#查询时会显示原始SQL语句
app.config['SQLALCHEMY_ECHO'] = True
#实例化db对象
db = SQLAlchemy(app)


# app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(seconds=10)
# import myweb.views