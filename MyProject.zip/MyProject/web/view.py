import os
from os import path
import time

from werkzeug.utils import secure_filename
from MyProject.web import app
from flask import Flask,render_template,request,flash
"""
给网页模板传递消息--flash，模板中需要遍历消息
flash--需要对内容进行加密，设置secret_key,做加密消息的混淆
"""


# 1.主页
@app.route('/')
def home():
    return render_template('index.html')

# 2.登录
@app.route('/login', methods=['GET', 'POST'])
def login():
    return render_template('login.html')

# 注销
@app.route('/logout')
def logout():
    return

#核心，上传
#获取文件所在目录的完整路径
#os.path.dirname(__file__)函数用于取出py所在文件夹的位置
#os.path.abspath(__file__)返回的是py文件的绝对路径
@app.route("/upload",methods=['GET','POST'])
def upload():
    error = None
    if request.method == 'POST':
        #获取到上传来的文件
        f = request.files['file']
        print(f)
        if (f.filename == ''):
            #使用flash进行消息的传递
            error="文件未上传"
        else:
            #定义基础的路径，即获取当前py文件的绝对路径
            base_path = path.abspath(path.dirname(__file__))
            #path.join函数是用于拼接，将该位置和后面指定的路径拼接在一起
            upload_path = path.join(base_path, r'static\testcase/')
            #上传文件文件名的安全获取
            try:
                now = time.localtime()
                nowt = time.strftime("%Y-%m-%d-%H_%M_%S", now)
                nfilename=nowt+f.filename
                f.save(path.join(upload_path,nfilename))
                print(nfilename)
                flash("文件上传成功")
            except IOError:
                error="Error: 没有找到文件或读取文件失败"
    return render_template('upload_testcase.html',error=error)

@app.route('/run', methods=['POST'])
def run():
    print("正在执行")
    return render_template('upload_testcase.html')

if __name__ == '__main__':
    app.run(debug=True)