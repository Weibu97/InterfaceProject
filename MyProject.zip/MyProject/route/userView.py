from MyProject.bin.config import app
from MyProject.api.userinfo import *
from flask import Flask, request
import json
@app.route('/new_login', methods=['GET', 'POST'])
def Login():
    resjson={}
    # 判断传入的json数据是否为空
    if request.get_data() is None:
        resjson['status'] = 0
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)
    # 获取传入的参数
    get_Data = request.get_data()
    print("传入的参数是"+str(get_Data))
    # 传入的参数为bytes类型，需要转化成json
    get_Data = json.loads(get_Data)
    username = get_Data.get('username')
    password = get_Data.get('password')
    result = valid_loginImpl(username, password)
    return json.dumps(result, ensure_ascii=False)




if __name__ == '__main__':
    app.run(debug=True)
