from MyProject.bin.config import app
from MyProject.api.caseinfo import*
from flask import request
from MyProject.Common.pubulic import *


@app.route('/case', methods=['GET'])
def case():
    resjson = {}
    # 获取传入的params参数
    get_data = request.args.to_dict()
    taskid = get_data.get('taskid')
    result = check_one_null(resjson, taskid)
    if result == True:
        result = find_case_all(taskid,casesid=0)
        return json.dumps(result, ensure_ascii=False)
    else:
        return result
    # try:
    #     # 获取传入的params参数
    #     get_data = request.args.to_dict()
    #     taskid = get_data.get('taskid')
    #     result=check_one_null(resjson,taskid)
    #     if result==True:
    #         result = find_case_all(taskid)
    #         return json.dumps(result, ensure_ascii=False)
    #     else:
    #         return result
    # except:
    #     resjson['status'] = '0'
    #     resjson['msg'] = '请求参数为空'
    #     return json.dumps(resjson, ensure_ascii=False)



@app.route('/case/add', methods=['POST'])
def addxtcs():
    resjson = {}
    try:
        # 获取传入的params参数
        get_data = request.get_data()
        get_data = json.loads(get_data)
        taskid = get_data.get('taskid')
        casesid = get_data.get('caseid')
        casemodel = get_data.get('casemodel')
        casname = get_data.get('casname')
        caseurl = get_data.get('caseurl')
        casepre = get_data.get('casepre')
        casemothod = get_data.get('casemothod')
        caseparam = get_data.get('caseparam')
        casepr = get_data.get('casepr')
        casestatus = get_data.get('casestatus')
        casepresult = get_data.get('casepresult')
        casefresult = get_data.get('casefresult')
        casetime = get_data.get('casetime')
        caseremark = get_data.get('caseremark')
        result=check_null(resjson,taskid,casemodel,casname,caseurl,casepre,casemothod,caseparam,
                              casestatus)
        if result==True:
            result = add_case(taskid,casemodel,casname,caseurl,casemothod,caseparam,casepr,casestatus,casepresult,casefresult,casetime,caseremark,casesid,casepre)
            return json.dumps(result, ensure_ascii=False)
        else:
            return result
    except:
        resjson['status'] = '0'
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)


@app.route('/case/modify', methods=['POST'])
def modifyxtcs():
    resjson = {}
    try:
        # 获取传入的params参数
        get_data = request.get_data()
        get_data = json.loads(get_data)
        id = get_data.get('id')
        taskid = get_data.get('taskid')
        casesid = get_data.get('caseid')
        casemodel = get_data.get('casemodel')
        casname = get_data.get('casname')
        caseurl = get_data.get('caseurl')
        casepre = get_data.get('casepre')
        casemothod = get_data.get('casemothod')
        caseparam = get_data.get('caseparam')
        casepr = get_data.get('casepr')
        casestatus = get_data.get('casestatus')
        casepresult = get_data.get('casepresult')
        casefresult = get_data.get('casefresult')
        casetime = get_data.get('casetime')
        caseremark = get_data.get('caseremark')
        result=check_null(resjson,id,taskid,casemodel,casname,caseurl,casepre,casemothod,caseparam,
                              casestatus)
        if result==True:
            result = modify_case(id,taskid,casemodel,casname,caseurl,casemothod,caseparam,casepr,casestatus,casepresult,casesid,casepre)
            return json.dumps(result, ensure_ascii=False)
        else:
            return result
    except:
        resjson['status'] = '0'
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)

@app.route('/case/delete', methods=['POST'])
def deletecase():
    resjson={}
    get_Data = request.get_data()
    get_Data = json.loads(get_Data)
    try:
        print("====================")
        get_Data=request.get_data()
        get_Data = json.loads(get_Data)
        print("传入的参数值是"+str(get_Data))
        id = get_Data.get('id')
        taskid =get_Data.get('taskid')
        result=check_null(resjson,id,taskid)
        if result==True:
            result=delete_case(id,taskid)
            return json.dumps(result,ensure_ascii=False)
        else:
            return result
    except:
        resjson['status'] = '0'
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)





if __name__ == '__main__':
    app.run(debug=True)