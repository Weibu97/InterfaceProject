from MyProject.bin.config import app
from MyProject.api.taskinfo import *
from flask import request
from MyProject.Common.pubulic import *
import json
from MyProject.Common.log import *
log=Demolog().log()

@app.route('/task', methods=['GET'])
def task():
    resjson={}
    try:
        log.info("task-正在进行task任务中心的查询")
        result=find_task_all()
        return json.dumps(result, ensure_ascii=False)
    except:
        log.error("task-请求出错")
        resjson['status'] = -1
        resjson['msg'] = '出现错误'
        return json.dumps(resjson, ensure_ascii=False)


@app.route('/task/add', methods=['POST'])
def addtask():
    resjson={}
    try:
        # 获取传入的参数
        get_Data = request.get_data()
        # 传入的参数为bytes类型，需要转化成json
        get_Data = json.loads(get_Data)
        log.info("addtask-前端传入的参数是" + str(get_Data))
        userid = get_Data.get('userid')
        taskname = get_Data.get('taskname')
        taskexplain = get_Data.get('taskexplain')
        result = check_null(resjson, userid, taskname, taskexplain)
        if result == True:
            log.info("addtask-校验空值成功,正在进行添加操作")
            result =add_task(userid,taskname,taskexplain)
            return json.dumps(result, ensure_ascii=False)
        else:
            return result
    except:
        log.error("addtask-前端传入的参数错误，结果是" + str(request.get_data()))
        resjson['status'] = -1
        resjson['msg'] = '请求参数错误'
        return json.dumps(resjson, ensure_ascii=False)

@app.route('/task/modify', methods=['POST'])
def modifytask():
    resjson={}
    try:
        get_Data=request.get_data()
        get_Data=json.loads(get_Data)
        id=get_Data.get('id')
        taskname=get_Data.get('taskname')
        taskexplain = get_Data.get('taskexplain')
        result=check_null(resjson,id,taskname,taskexplain)
        if result == True:
            result=modify_taskname(id,taskname,taskexplain)
            return json.dumps(result, ensure_ascii=False)
        else:
            return result
    except:
        log.error("modifytask-前端传入的参数错误，结果是" + str(request.get_data()))
        resjson['status'] = -1
        resjson['msg'] = '请求参数错误'
        return json.dumps(resjson, ensure_ascii=False)


@app.route('/task/task_id', methods=['GET'])
def task_by_id():
    resjson={}
    try:
        # 获取传入的params参数
        get_data = request.args.to_dict()
        id = get_data.get('id')
        result=check_null(resjson,id)
        if result==True:
            result=find_task_by_id(id)
            return json.dumps(result, ensure_ascii=False)
        else:
            return result
    except:
        log.error("task-前端传入的参数错误，结果是" + str(request.args.to_dict()))
        resjson['status'] = '0'
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)


@app.route('/task/delete', methods=['GET'])
def deletetask():
    resjson={}
    try:
        get_Data=request.args.to_dict()
        id =get_Data.get('id')
        result=check_one_null(resjson,id)
        if result==True:
            result=delete_task(id)
            return json.dumps(result,ensure_ascii=False)
        else:
            return result
    except:
        log.error("task-前端传入的参数错误，结果是" + str(request.args.to_dict()))
        resjson['status'] = '0'
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)



if __name__ == '__main__':
    app.run(debug=True)