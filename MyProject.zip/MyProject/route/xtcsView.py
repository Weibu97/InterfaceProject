from MyProject.bin.config import app
from MyProject.api.xtcsinfo import *
from flask import request
from MyProject.Common.pubulic import *


@app.route('/xtcs', methods=['GET'])
def xtcs():
    resjson = {}
    try:
        # 获取传入的params参数
        get_data = request.args.to_dict()
        taskid = get_data.get('taskid')
        result=check_one_null(resjson,taskid)
        if result==True:
            result = find_xtcs_all(taskid)
            return json.dumps(result, ensure_ascii=False)
        else:
            return result
    except:
        resjson['status'] = '0'
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)

@app.route('/xtcs/add', methods=['POST'])
def addxtcs():
    resjson={}
    get_Data = request.get_data()
    # 传入的参数为bytes类型，需要转化成json
    get_Data = json.loads(get_Data)
    try:
        # 获取传入的参数
        get_Data = request.get_data()
        # 传入的参数为bytes类型，需要转化成json
        get_Data = json.loads(get_Data)
        taskid=get_Data.get("taskid")
        gcsname=get_Data.get("gcsname")
        gcsvalue=get_Data.get("gcsvalue")
        result=check_null(resjson,taskid,gcsname,gcsvalue)
        if result== True:
            if taskid==0:
                result=add_global_xtcs(gcsname,gcsvalue,taskid)
                return result
            else:
                task = Task.query("id", taskid)
                if task:
                    result = add_global_xtcs(gcsname, gcsvalue, taskid)
                    return result
                else:
                    resjson['status'] = '-2'
                    resjson['msg'] = '找不到相关信息'
                    return json.dumps(resjson, ensure_ascii=False)
        else:
            return result
    except:
        resjson['status'] = '0'
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)

@app.route('/xtcs/modify', methods=['POST'])
def modifyxtcs():
    resjson={}
    get_Data = request.get_data()
    # 传入的参数为bytes类型，需要转化成json
    get_Data = json.loads(get_Data)
    try:
        # 获取传入的参数
        get_Data = request.get_data()
        # 传入的参数为bytes类型，需要转化成json
        get_Data = json.loads(get_Data)
        taskid = get_Data.get("taskid")
        gcsname = get_Data.get("gcsname")
        gcsvalue = get_Data.get("gcsvalue")
        result = check_null(resjson, taskid, gcsname, gcsvalue)
        if result == True:
            result = modify_global_xtcsname(gcsname, gcsvalue, taskid)
            return result
        else:
            return result
    except:
        resjson['status'] = '0'
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)

@app.route('/xtcs/delete', methods=['POST'])
def deletextcs():
    resjson={}
    try:
        get_Data=request.get_data()
        get_Data = json.loads(get_Data)
        taskid =get_Data.get('taskid')
        gcsname = get_Data.get('gcsname')
        result=check_null(resjson,taskid,gcsname)
        if result==True:
            result=delete_xtcs(taskid,gcsname)
            return json.dumps(result,ensure_ascii=False)
        else:
            return result
    except:
        resjson['status'] = '0'
        resjson['msg'] = '请求参数为空'
        return json.dumps(resjson, ensure_ascii=False)




if __name__ == '__main__':
    app.run(debug=True)