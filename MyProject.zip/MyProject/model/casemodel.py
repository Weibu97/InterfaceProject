# 用例表
# id
# taskid 任务的id，与任务中心挂钩 必填项
# casesid  测试组，即这条用例里面存在多条联通性
# casemodel 测试的模块
# casname 测试用例的名称
# caseurl 测试的url
# casepre 测试用例的前置
# casemothod 测试用例的方式
# caseparam 请求参数
# casepr 优先级
# casestatus 测试用例的状态码
# casepresult 预期结果，存在多条，以';'进行分割，如 statues:==:200;name:==:user
# casefresult 最终结果，成功的话就为成功，失败的话就返回失败:原因是XXX为XX，不符合预期
# casetime 用例的运行时间
# caseremark 用例的备注

from MyProject.web import db
from sqlalchemy import insert,update,and_
from MyProject.model.model import Case

class CaseModel():
    #新增
    def insert(self,taskid,casemodel,casname,caseurl,casemothod,caseparam,casepr,casestatus,casepresult,casefresult,casetime,caseremark,casesid='',casepre=''):
        try:
            result = insert(Case).values(taskid=taskid, casesid=casesid,casemodel=casemodel,casname=casname,
                                         casepre=casepre,caseurl=caseurl,casemothod=casemothod,caseparam=caseparam,
                                         casepr=casepr,casestatus=casestatus,casepresult=casepresult,
                                         casefresult=casefresult,casetime=casetime,caseremark=caseremark)
            case=db.session.execute(result)
            return case
        except:
            return False
    #单条查询
    def query(self,prama,value):
        try:
            if prama=="id":
                case=Case.query.filter(Case.id ==value ).first()
                return case
            elif prama=="casesid":
                case = Case.query.filter(Case.casesid == value).first()
                return case
            else:
                return False
        except:
            return False
    #多条查询
    def querys_all(self,taskid,casesid=0):
        if casesid:
            try:
                case=Case.query.filter(and_(Case.taskid==taskid,Case.casesid==casesid)).all()
                return case
            except:
                return False
        else:
            try:
                case=Case.query.filter(Case.taskid==taskid).all()
                return case
            except:
                return False

     #删除用例，根据id或taskid
    def delete(self,id,taskid):
        try:
            print("执行删除")
            case=Case.query.filter(and_(Case.id==id,Case.taskid == taskid)).delete()
            print("删除的结果是"+str(case))
            return case
        except:
            return False

    # 删除用例，根据taskid+casesid
    def delete_case_group(self, id,taskid,casesid):
        try:
            Case.query.filter(and_(Case.id==id,Case.taskid == taskid,Case.casesid==casesid)).delete()
            return True
        except:
            return False


#修改
    def update(self,id,taskid,casemodel,casname,caseurl,casemothod,caseparam,casepr,casestatus,casepresult,casesid='',casepre=''):
        try:
            case=update(Case).where(and_(Case.id==id,Case.taskid==taskid)).values(taskid=taskid, casesid=casesid,casemodel=casemodel,casname=casname,
                                         casepre=casepre,caseurl=caseurl,casemothod=casemothod,caseparam=caseparam,
                                         casepr=casepr,casestatus=casestatus,casepresult=casepresult)
            case1=db.session.execute(case)
            # 返回受影响的条数,进行判断
            if case1.rowcount==0:
                return False
            else:
                return True
        except:
            return False




