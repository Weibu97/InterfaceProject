from MyProject.web import db
from sqlalchemy import insert,update,and_
#创建user模型类
class User(db.Model):
    #定义表名
    __tablename__ = 'user'
    # 防止表存在时重复生成表
    __table_args__ = {"useexisting": True}
    #开始添加表中需要的字段
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    username = db.Column(db.String(100),nullable=False,unique=True)
    password = db.Column(db.String(80),nullable=False)
    def __repr__(self):
        #设置外键
        return '<User %r>' % self.id

class Task(db.Model):
    #定义表名
    __tablename__ = 'task'
    # 防止表存在时重复生成表
    __table_args__ = {"useexisting": True}
    #开始添加表中需要的字段
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    userid=db.Column(db.Integer,nullable=False)
    taskname = db.Column(db.String(100),nullable=False,unique=True)
    taskexplain = db.Column(db.String(80),nullable=False)
    taskstatus = db.Column(db.String(80))
    taskresult = db.Column(db.String(80))
    tasktime = db.Column(db.String(80))
    def __repr__(self):
        #设置外键
        return '<Task %r>' % self.id


class XTCS(db.Model):
    #定义表名
    __tablename__ = 'xtcs'
    # 防止表存在时重复生成表
    __table_args__ = {"useexisting": True}
    #开始添加表中需要的字段
    taskid=db.Column(db.Integer,primary_key=True)
    gcsname = db.Column(db.String(100),nullable=False,primary_key=True)
    gcsvalue = db.Column(db.String(80),nullable=False,primary_key=True)
    gcstime = db.Column(db.String(80))
    def __repr__(self):
        #设置外键
        return '<XTCS %r>' % self.taskid

class Case(db.Model):
    #定义表名
    __tablename__ = 'case'
    # 防止表存在时重复生成表
    __table_args__ = {"useexisting": True}
    #开始添加表中需要的字段
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    taskid=db.Column(db.Integer,nullable=False)
    casesid = db.Column(db.String(100))
    casemodel = db.Column(db.String(80),nullable=False)
    casname = db.Column(db.String(80), nullable=False)
    caseurl = db.Column(db.String(80), nullable=False)
    casepre = db.Column(db.String(80))
    casemothod = db.Column(db.String(80), nullable=False)
    caseparam = db.Column(db.String(80))
    casepr = db.Column(db.String(80), nullable=False)
    casestatus = db.Column(db.String(80), nullable=False)
    casepresult = db.Column(db.String(80))
    casefresult = db.Column(db.String(80))
    casetime = db.Column(db.String(80))
    caseremark = db.Column(db.String(80))
    def __repr__(self):
        #设置外键
        return '<Case %r>' % self.id


#将字段打印出来
def obtain_xtcs_value(dictname,xtcs):
    dictname['taskid'] = xtcs.taskid
    dictname['gcsname'] = xtcs.gcsname
    dictname['gcsvalue'] = xtcs.gcsvalue
    dictname['gcstime'] = xtcs.gcstime
    return dictname
if __name__=="__main__":
    flag=1
    #定义一个flag来进行开关，是创建表、情况表 还是要插入数据
    if flag==0:
        # db.drop_all() ##清空表
        db.create_all()#创建所有表，所有的db.Model
    if flag==1:
        # # 添加User数据
        # tag0 = User(username='cc',password='aaa')
        # db.session.add(tag0)
        # aa=db.session.commit()
        # print(aa)
        #查询数据
        # all = db.session.query(User).all()
        # first = db.session.query(User).first()
        # print(first)
        #添加task数据
        # tag0 = Task(userid=1,taskname='登录中心任务',taskexplain='登录中心的用例',taskstatus='1',taskresult='1',tasktime='20210304')
        # tag1 = Task(userid=1,taskname='登录中心任务2',taskexplain='登录中心的用例',taskstatus='1',taskresult='1',tasktime='20210304')
        # db.session.add(tag0)
        # db.session.add(tag1)
        # db.session.commit()
        # # 查询数据
        # all = db.session.query(Task).all()
        # print(all)
        #添加系统参数的值
        # 查询数据
        # tag0 = XTCS(taskid=4,gcsname='header',gcsvalue='err',gcstime='20210304')
        #         # tag1 = XTCS(taskid=4,gcsname='header1',gcsvalue='err1',gcstime='20210304')
        #         # db.session.add(tag0)
        #         # db.session.add(tag1)
        #         # result=db.session.commit()
        # result=insert(XTCS).values(taskid=5,gcsname='header',gcsvalue='err',gcstime='20210304')
        # query = update(XTCS).where(and_(XTCS.taskid==5,XTCS.gcsname=='header1')).values(gcsname='header555')
        # db.session.execute(query)
        # # 显示新增的条数
        # print(db.session.execute(query))
        resjson={}
        xtcs=XTCS.query.filter(and_(XTCS.taskid == '0', XTCS.gcsname == '2')).delete()
        print(str(xtcs))
        # if xtcs:
        #     resjson['status'] = 1
        #     resjson['msg'] = "查询成功"
        #     dictname = resjson['result'] = {}
        #     obtain_xtcs_value(dictname, xtcs)
        #     print(resjson)

