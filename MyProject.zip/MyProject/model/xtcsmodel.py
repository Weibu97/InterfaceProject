# 系统参数，用于设置全局变量
# taskid 与任务的id相联系，一个任务可以设置多个系统参数，不同的任务可以设置相同的参数名
# gcsname 全局变量的参数名，可以重复，但是taskid-gcsname不能重复
# gcsvalue  全局变量的参数值
# gcstime  全局变量的设置时间

from MyProject.web import db
from sqlalchemy import insert,update,and_,delete
from MyProject.model.model import XTCS
class XTCSModel():
    def insert(self,gcsname,gcsvalue,taskid=0):
        try:
            xtcs=insert(XTCS).values(taskid=taskid,gcsname=gcsname,gcsvalue=gcsvalue)
            db.session.execute(xtcs)
            return True
        except:
            return False

    def query(self,param,pvalue):
        try:
            if param=='taskid':
                task=XTCS.query.filter(XTCS.taskid==pvalue).first()
            elif param=='gcsname':
                task=XTCS.query.filter(XTCS.gcsname==pvalue).first()
            else:
                return False
            return True
        except:
            return False

    def querys(self,taskid,gcsname):
        try:
            task = XTCS.query.filter(and_(XTCS.taskid == taskid,XTCS.gcsname==gcsname)).first()
            return task
        except:
            return False

    def update(self,gcsname,gcsvalue,taskid=0):
        try:
            task=update(XTCS).where(and_(XTCS.taskid==taskid,XTCS.gcsname ==gcsname, XTCS.gcsvalue == gcsvalue)).values(gcsname=gcsname,gcsvalue=gcsvalue)
            db.session.execute(task)
            return task
        except:
            return False

    def delete(self,gcsname,taskid=0):
        try:
            xtcs=XTCS.query.filter(and_(XTCS.taskid==taskid,XTCS.gcsname==gcsname)).delete()
            return True
        except:
            return False

    def querys_all(self,taskid):
        try:
            xtcs=XTCS.query.filter(XTCS.taskid==taskid).all()
            return xtcs
        except:
            return False




