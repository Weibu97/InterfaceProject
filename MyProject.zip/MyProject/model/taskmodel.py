# task 任务表
# 操作：增删改查
# id  任务id
# userid  与用户表关联
# taskname 任务名称
# taskexplain 任务内容
# taskstatus 任务状态
# taskresult 任务结果
# tasktime 任务运行时间

from MyProject.web import db
from sqlalchemy import insert,update,and_
from MyProject.model.model import Task
import datetime
def obtain_time():
    time=datetime.datetime.now().strftime('%Y%m%d-%H:%M:%S')
    return time

class TaskModel():
    def query(self,param,value):
        try:
            if param == 'taskname':
                task=Task.query.filter(Task.taskname == value).first()
            elif param=='userid':
                task = Task.query.filter(Task.userid == value).first()
            elif param=='id':
                task = Task.query.filter(Task.id == value).first()
            else:
                return False
            return task
        except:
            return False

    def insert(self,userid,taskname,taskexplain):
        try:
            time=obtain_time()
            task = insert(Task).values(userid=userid, taskname=taskname, taskexplain=taskexplain,tasktime=time)
            db.session.execute(task)
            return True
        except:
            return False

    def update(self,id,taskname,taskexplain):
        try:
            time=obtain_time()
            task = update(Task).where(Task.id ==id).values(taskname=taskname,taskexplain=taskexplain,tasktime=time)
            db.session.execute(task)
            return True
        except:
            return False

    def delete(self,id):
        try:
            Task.query.filter(Task.id == id).delete()

            return True
        except:
            return False

    def querys_all_userid(self,userid):
        try:
            tasks=Task.query.filter(Task.userid==userid).all()
            return tasks
        except:
            return False

    def querys_all(self):
        try:
            tasks=Task.query.filter().all()
            return tasks
        except:
            return False






