from MyProject.model.model import User
class userModel:
    def query(self,username):
        try:
            user = User.query.filter(User.username == username).first()
            return user
        except:
            return False

    def query_all(self):
        try:
            users = User.query.filter().all()
            return users
        except:
            return False