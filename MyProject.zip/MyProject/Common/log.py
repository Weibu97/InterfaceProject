import logging
import time
import os
#定义一个带参数的装饰器，用于添加日志时加上具体某个中心的开头便于检查
# def Addname(name):
#     def decorator(func):
#         def inner():
#             ret="name"+func
#             return ret

class Demolog:
    def __init__(self,logger=None):
        #创建一个日志器
        self.logger=logging.getLogger("logger")
        #设置日志输出的最低等级，要是低于这个等级就不会输出
        self.logger.setLevel(logging.DEBUG)
        if not self.logger.handlers:
            #设置日志路径
            self.log_path=os.path.join(os.path.dirname(os.getcwd()),"log","")
            # print("当前路径是"+str(self.log_path))
            self.log_time=time.strftime("%Y_%m_%d",time.localtime())
            self.log_name=self.log_path+self.log_time+'log.log'
            # #创建一个处理器
            # ch=logging.StreamHandler()
            #创建文件处理器,注意:使用filemode="a"附加模式。
            ch_f=logging.FileHandler(self.log_name,'a',encoding="utf-8")
            ch_f.setLevel(logging.DEBUG)
            #创建一个格式器,定义handler的输出格式
            format=logging.Formatter(fmt="%(asctime)s - %(filename)s[line:%(lineno)d - %(levelname)s: %(message)s",
                                     datefmt="%Y/%m%d/%X")
            #将格式器设置进处理器
            # ch.setFormatter(format)
            ch_f.setFormatter(format)
            #将处理器添加到日志对象里面
            self.logger.addHandler(ch_f)
            ch_f.close()
            # 日志记录后移除句柄
            # self.logger.removeFilter(ch_f)
    def log(self):
        return self.logger
        # logging.debug("这是一个debug级别的日志信息")
        # logging.info("这是一个info级别的日志信息")
        # logging.warning("这是一个warning级别的日志信息")
        # logging.error("这是一个error级别的日志信息")
        # logging.critical("这是一个critical级别的日志信息")

if __name__ == '__main__':
    # @Addname("测试一下")
    def log():
        log=Demolog().log()
        return log
    def sum(a,b):
        log().info("kkkkk")
        print("hhh")
    sum(1,2)