import json
from MyProject.Common.log import *
log=Demolog().log()
def check_one_null(resjson,args):
    log.info("正在进入到参数空值校验,校验参数值为" + str(args))
    if len(str(args))<=0:
        log.error("当前参数校验结果为空值")
        resjson['status'] = -1
        resjson['msg'] = '请求参数值有误'
        return json.dumps(resjson, ensure_ascii=False)
    else:
        return True
def check_null(resjson,*args):
    for i in args:
        log.info("正在进入到参数空值校验,校验参数值为"+str(i))
        if len(str(i))<=0:
            log.error("当前参数校验结果为空值")
            resjson['status'] = -1
            resjson['msg'] = '请求参数值有误'
            return json.dumps(resjson, ensure_ascii=False)
    return True
